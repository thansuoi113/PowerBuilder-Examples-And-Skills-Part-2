//+-------------------------------------------------------------------
//
//  PowerPrinter
//
//  Copyright (c) 1997, 1998, 1999, 2000, 2001
//  SecureWave. All rights reserved
//
//  See the file LICENSE.TXT for redistribution information.
//
//  Contents:    source file that includes just the standard includes
//				 powerprn.pch will be the pre-compiled header             
//				 stdafx.obj will contain the pre-compiled type information
//
//--------------------------------------------------------------------

#include "stdafx.h"

