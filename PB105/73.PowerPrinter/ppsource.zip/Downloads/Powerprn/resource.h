//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by powerprn.rc
//
#define IDD_ABOUT                       129
#define IDD_REGISTER                    130
#define IDI_ICON1                       131
#define IDC_REGISTERBTN                 1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
